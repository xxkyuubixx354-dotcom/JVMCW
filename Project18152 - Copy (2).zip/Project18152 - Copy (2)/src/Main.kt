import javax.swing.JFrame


fun main() {
    SaveSystem.createTable()
    SaveSystem.showTable()

    val frame = JFrame("MainPanel")
    frame.setContentPane(MenuPage().MainPanel)
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
    frame.pack()
    frame.setVisible(true)

    if(SaveSystem.checkIfEmpty())
    {
        MenuPage.instance.viewEventsButton.isEnabled = false;
        MenuPage.instance.registerParticipantButton.isEnabled = false;
        MenuPage.instance.slotFinderButton.isEnabled = false
        MenuPage.instance.eventSchedulerButton.isEnabled = false
    }
}



fun concatenateInfo(event: Event, venue: Venue) {
    val eventInfo = "${event.id}|||${event.name}|||${event.date}|||${event.startTime}|||${event.endTime}"
    val venueInfo = "${venue.id}|||${venue.name}|||${venue.location}|||${venue.capacity}"

    SaveSystem.insertData(eventInfo, venueInfo)
}

fun generateRandomID(length: Int = 8): String {
    val charset = ('A'..'Z') + ('a'..'z') + ('0'..'9')
    return (1..length)//iterating whole charset length
        .map { charset.random() }
        .joinToString("")
}