public class InformationControl {

}