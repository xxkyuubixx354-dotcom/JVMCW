import java.time.LocalDate
import java.time.LocalTime

data class TempEvent(
    val venueID: String = "",
    val eventName: String = "",
    val venue : String = "",
    val location: String = "",
    val date: LocalDate = LocalDate.MIN,
    val startTime: LocalTime = LocalTime.MIN,
    val endTime: LocalTime = LocalTime.MAX,
    val capacity: Int = 0,
    val currentCapacity: Int = 0

)
