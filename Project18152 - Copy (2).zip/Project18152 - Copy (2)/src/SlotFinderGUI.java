import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import scala.jdk.javaapi.CollectionConverters;

public class SlotFinderGUI {
    private JTextField participantField;
    private JTextField dateField;
    private JButton findEventButton;
    private JTextField timeField;
    public JPanel MainPanel;
    private JButton backButton;

    public SlotFinderGUI() {
        findEventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                var vID = ""; var eName = ""; var venue = ""; var loc = "";
                var date = LocalDate.MAX; var start = LocalTime.MIN; var end = LocalTime.MAX;

                EventPageInputs inputs = new EventPageInputs();
                TempEvent event = new TempEvent();
                //repeating particpant field in place of capacity because its a required parameter
                if(inputs.validateNumbers(participantField, participantField) &&
                        inputs.validateDate(dateField))
                {
                    SlotFinder slotFinder = new SlotFinder();
                    String spaces = slotFinder.findSlot(
                            Integer.parseInt(participantField.getText()),
                            LocalDate.parse(dateField.getText()), slotFinder.buildList());

                    for (int i = 0; i < SaveSystem.INSTANCE.getCurrentTable().size(); i++)
                    {
                        if(SaveSystem.INSTANCE.getCurrentTable().get(i).getVenueID().equals(spaces))
                        {
                            vID = SaveSystem.INSTANCE.getCurrentTable().get(i).getVenueID();
                            eName = SaveSystem.INSTANCE.getCurrentTable().get(i).getEventName();
                            venue = SaveSystem.INSTANCE.getCurrentTable().get(i).getVenue();
                            loc = SaveSystem.INSTANCE.getCurrentTable().get(i).getLocation();
                            date = SaveSystem.INSTANCE.getCurrentTable().get(i).getDate();
                            start = SaveSystem.INSTANCE.getCurrentTable().get(i).getStartTime();
                            end = SaveSystem.INSTANCE.getCurrentTable().get(i).getEndTime();
                        }
                    }


                    if (spaces != "") {
                        JOptionPane.showMessageDialog(null,
                                ("Venue ID: " + vID + "\n" +
                                        "Event: " + eName + "\n" +
                                        "Venue: " + venue + "\n" +
                                        "Location: " + loc + "\n" +
                                        "Date: " + date + "\n" +
                                        "Time: " + start + " - " + end +"\n"), "Event Found!", JOptionPane.PLAIN_MESSAGE);
                    } else
                        JOptionPane.showMessageDialog(null, "No Events Currently Available!", "Sorry", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("MenuPage");
                frame.setContentPane(new MenuPage().MainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

                //AI
                SwingUtilities.getWindowAncestor(MainPanel).dispose();
            }
        });
    }
}
