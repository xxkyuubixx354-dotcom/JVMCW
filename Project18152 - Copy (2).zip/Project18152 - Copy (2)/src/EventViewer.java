import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class EventViewer {

    public static EventViewer instance;
    public JPanel mainPanel;
    private JTable eventTable;
    private JButton backButton;

    public EventViewer() {

        instance = this;

        String[] columnNames = {"Event", "Date", "Start", "End", "Venue", "Location", "Venue ID", "Status"};

        int size = SaveSystem.INSTANCE.getCurrentTable().size();
        String[][] data = new String[size][columnNames.length];

        for (int i = 0; i < size; i++) {

            TempEvent e = SaveSystem.INSTANCE.getCurrentTable().get(i);
            data[i][0] = e.getEventName();
            data[i][1] = e.getDate().toString();
            data[i][2] = e.getStartTime().toString();
            data[i][3] = e.getEndTime().toString();
            data[i][4] = e.getVenue();
            data[i][5] = e.getLocation();
            data[i][6] = e.getVenueID();
            boolean b = e.getCurrentCapacity() < e.getCapacity();
            if(b)
                data[i][7] = "Available";
            else
                data[i][7] = "Full";
        }

        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        eventTable.setModel(model);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("MenuPage");
                frame.setContentPane(new MenuPage().MainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

                //AI
                SwingUtilities.getWindowAncestor(mainPanel).dispose();
            }
        });
    }
}
