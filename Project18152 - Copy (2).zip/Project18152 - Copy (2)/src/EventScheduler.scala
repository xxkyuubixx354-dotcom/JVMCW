import java.sql.{Connection, DriverManager, PreparedStatement, Statement}
import java.time.{LocalDate, LocalTime}
import scala.jdk.CollectionConverters._

class EventScheduler {

  val eventNames: List[TempEvent] = Nil
  val venueNames: List[TempEvent] = Nil

  val events: List[TempEvent] = Nil

  def buildList(): List[TempEvent] =
    SaveSystem.INSTANCE.getCurrentTable.asScala.toList


  def findEventsByEvent(eventName: String, eventList: List[TempEvent], selectedEvents: List[TempEvent]): List[TempEvent]= {
    eventList match {
      case Nil => selectedEvents
      case head :: tail =>
        if (eventName == head.getEventName) {
          findEventsByEvent(eventName, tail, head :: selectedEvents)
        }
        else {
          findEventsByEvent(eventName, tail, selectedEvents)
        }
    }
  }

  def findEventsByVenue(venue: String, venueList: List[TempEvent], selectedEvents: List[TempEvent]): List[TempEvent]= {
    venueList match {
      case Nil => selectedEvents
      case head :: tail =>
        if (venue == head.getVenue) {
          findEventsByVenue(venue, tail, head :: selectedEvents)
        }
        else {
          findEventsByVenue(venue, tail, selectedEvents)
        }
    }
  }

  def combineEvents(eventNameEvents : List[TempEvent], venueNameEvents : List[TempEvent]): List[TempEvent] = {
    venueNameEvents match {
      case Nil => eventNameEvents
      case head :: tail =>
        combineEvents(head :: eventNameEvents, tail)
  }}

    def createSchedule(list: List[TempEvent], currentResults: List[TempEvent]): List[TempEvent]= {
      list match {
        case Nil => currentResults
        case head :: tail =>
          if (currentResults.isEmpty || !head.getDate.isEqual(currentResults.head.getDate))
            createSchedule(tail, head +: currentResults)
          else if (head.getEndTime.isBefore(currentResults.head.getStartTime) || head.getStartTime.isAfter(currentResults.head.getEndTime))
              createSchedule(tail, head +: currentResults)
            else
              createSchedule(tail, currentResults)
      }
      currentResults
    }
}

