import scala.collection.immutable.List;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class EventSchedulerGUI {
    private JTextField eventNameField;
    private JTextField venueField;
    private JButton buildScheduleButton;
    private JButton submitDetailsButton;
    private JButton submitVenueButton;
    private JButton backButton;
    public JPanel MainPanel;

    private final EventScheduler scheduler = new EventScheduler();

    private  List<TempEvent>allEvents;
    private List<TempEvent> scalaEvents;
    private List<TempEvent> eventEvents;
    private List<TempEvent> venueEvents;

    public EventSchedulerGUI() {
        submitDetailsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                eventEvents = scheduler.findEventsByEvent(eventNameField.getText(), scheduler.buildList(), scheduler.eventNames());


            }
        });
        submitVenueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                venueEvents = scheduler.findEventsByVenue(venueField.getText(), scheduler.buildList(), scheduler.venueNames());
            }
        });
        buildScheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                allEvents = scheduler.combineEvents(eventEvents, venueEvents);
                scalaEvents = scheduler.createSchedule(allEvents, scalaEvents);
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("MenuPage");
                frame.setContentPane(new MenuPage().MainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

                //AI
                SwingUtilities.getWindowAncestor(MainPanel).dispose();
            }
        });
    }
}
