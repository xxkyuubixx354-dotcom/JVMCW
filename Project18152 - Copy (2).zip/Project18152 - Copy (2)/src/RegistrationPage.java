import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegistrationPage {
    public JPanel MainPanel;
    private JTextField venueIDField;
    private JTextField nameField;
    private JTextField addressField;
    private JTextField emailField;
    private JButton completeRegistrationButton;
    private JButton backButton;

    public RegistrationPage() {
        completeRegistrationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                EventPageInputs inputs = new EventPageInputs();

                if(inputs.validateStrings(nameField, nameField, addressField, emailField) && inputs.validateID(venueIDField))
                {
                    if(!SaveSystem.INSTANCE.addToVenue(venueIDField.getText()))
                        JOptionPane.showMessageDialog(null, "Participant Added!", "Message", JOptionPane.PLAIN_MESSAGE);
                    else
                        JOptionPane.showMessageDialog(null, "Event Full!", "Message", JOptionPane.PLAIN_MESSAGE);

                    JFrame frame = new JFrame("MenuPage");
                    frame.setContentPane(new MenuPage().MainPanel);
                    frame.pack();
                    frame.setLocationRelativeTo(null);
                    frame.setVisible(true);

                    //AI
                    SwingUtilities.getWindowAncestor(MainPanel).dispose();


                }
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("MenuPage");
                frame.setContentPane(new MenuPage().MainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

                //AI
                SwingUtilities.getWindowAncestor(MainPanel).dispose();
            }
        });
    }



}
