data class Venue(
    val id: String,
    val name: String,
    val location: String,
    val capacity: Int,
    val currentCapacity: Int
)