import scala.jdk.CollectionConverters._
import java.time.LocalDate

class SlotFinder {

  def buildList(): List[TempEvent] =
    SaveSystem.INSTANCE.getCurrentTable.asScala.toList

  def findSlot(requiredCapacity: Int, date: LocalDate, events: List[TempEvent]): String = {
    events match {
      case Nil => ""
      case head :: tail =>
        val remainingSpaces = head.getCapacity - head.getCurrentCapacity
        val validCapacity = remainingSpaces >= requiredCapacity
        val validDate = (date == head.getDate || date.isBefore(head.getDate))
        if (validCapacity && validDate) {
          head.getVenueID
        } else
          findSlot(requiredCapacity, date, tail)
    }
  }
}

