import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EventPage{
    public JTextField nameField;
    public JTextField dateField;
    public JTextField startField;
    private JTextField endField;
    public JTextField venueNameField;
    public JTextField venueLocationField;
    public JTextField venueCapacityField;
    public JButton goButton;
    public JPanel MainPanel;
    private JTabbedPane tabbedPane1;
    private JButton backButton;



    public EventPage() {
        goButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                EventPageInputs inputs = new EventPageInputs();

                //repeating venuelocation field in place of email as its a required param
                if(inputs.validateStrings(nameField, venueNameField, venueLocationField,  new JTextField("@") )&&
                        inputs.validateDate(dateField) &&
                        inputs.validateTime(startField) &&
                        inputs.validateTime(endField) &&
                        inputs.validateNumbers(venueCapacityField, venueCapacityField)) {

                    Event event = new Event(
                            MainKt.generateRandomID(8),
                            nameField.getText(),
                            dateField.getText(),
                            startField.getText(),
                            endField.getText()

                    );

                    Venue venue = new Venue(
                            MainKt.generateRandomID(6),
                            venueNameField.getText(),
                            venueLocationField.getText(),
                            Integer.parseInt(venueCapacityField.getText()),
                            0
                    );


                   SwingUtilities.getWindowAncestor(MainPanel).dispose();


                    JOptionPane.showMessageDialog(null, "Event Created!", "Message", JOptionPane.PLAIN_MESSAGE);
                    JFrame frame = new JFrame("MenuPage");
                    frame.setContentPane(new MenuPage().MainPanel);
                    frame.pack();
                    frame.setLocationRelativeTo(null);
                    frame.setVisible(true);

                    MainKt.concatenateInfo(event,venue);

                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("MenuPage");
                frame.setContentPane(new MenuPage().MainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

                //AI
                SwingUtilities.getWindowAncestor(MainPanel).dispose();
            }
        });
    }
}