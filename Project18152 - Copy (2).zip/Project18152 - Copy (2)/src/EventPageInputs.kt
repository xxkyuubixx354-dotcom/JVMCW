import javax.swing.JOptionPane
import javax.swing.JTextField
import java.text.SimpleDateFormat

class EventPageInputs {

    var valid = true;

    fun validateDate(date : JTextField): Boolean
    {
        valid = true
        val dateFormat = SimpleDateFormat("yyyy-MM-dd")
        dateFormat.isLenient = false

        try {
            dateFormat.parse(date.text)
        } catch (e: Exception) {
            println(37)
            missingInvalidInputs()
        }

        val splitDate = date.getText().split("-")
        val y = splitDate.getOrNull(0)
        val m = splitDate.getOrNull(1)
        val d = splitDate.getOrNull(2)

        if(y?.toInt() !in 2025..2026 || m?.toInt() !in 0..12 ||  d?.toInt() !in 1..31) {
            println(47)
            missingInvalidInputs()
        }

        return valid
    }
    fun validateTime(time: JTextField): Boolean
    {
        valid = true
        val timeFormat = SimpleDateFormat("HH:mm")
        timeFormat.isLenient = false

        try {
            timeFormat.parse(time.text)
        } catch (e: Exception) {
            println(77)
            missingInvalidInputs()
        }

        val splitTime = time.getText().split(":")
        val h = splitTime.getOrNull(0)
        val mn = splitTime.getOrNull(1)

        if(h?.toInt() !in 0..24 || mn?.toInt() !in 0..59) {
            println(88)
            missingInvalidInputs()
        }

        return valid
    }

    fun validateNumbers(participants: JTextField, capacity: JTextField) : Boolean
    {
        val c: Boolean = capacity.text.toIntOrNull() != null && capacity.text.toInt() > 0
        if (!c) {
            println(42222)
            missingInvalidInputs()
        }

        val p: Boolean = participants.text.toIntOrNull() != null && participants.text.toInt() > 0
        if(!p) {
            println(476)
            missingInvalidInputs()
        }

        return valid
    }


    fun validateStrings(name : JTextField, venue : JTextField,location : JTextField, email : JTextField): Boolean
    {
        //name, venue, location, email - strings
        if(name.getText().isBlank() || venue.getText().isBlank() || location.getText().isBlank() || email.getText().isBlank()) {
            missingInvalidInputs()
            println(44354)
            return valid
        }
        if(!email.toString().contains("@")) {
            println(3422)
            missingInvalidInputs()
        }

        return valid
    }


    fun validateID(venueID: JTextField): Boolean
    {
        if(venueID.getText().count() != 6)
        {
            println(47324324)
            missingInvalidInputs()
        }
        return valid
    }


    fun missingInvalidInputs()
    {
        JOptionPane.showMessageDialog(null, "Missing or Invalid Input(s)", "Message", JOptionPane.PLAIN_MESSAGE);
        valid = false
    }

}