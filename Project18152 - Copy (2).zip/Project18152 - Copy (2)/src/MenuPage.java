import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuPage extends JFrame {

    public static MenuPage instance;
    public JButton createEventButton;
    public JPanel MainPanel;
    public JButton registerParticipantButton;
    public JButton slotFinderButton;
    public JButton eventSchedulerButton;
    private JButton exitButton;
    public JButton viewEventsButton;


    public MenuPage() {

        instance = this;
        instance.setLocationRelativeTo(null);

        createEventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("EventPage");
                frame.setContentPane(new EventPage().MainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                SwingUtilities.getWindowAncestor(MainPanel).dispose();
            }

        });

        viewEventsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("EventViewer");
                frame.setContentPane(new EventViewer().mainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                SwingUtilities.getWindowAncestor(MainPanel).dispose();
            }
        });

        registerParticipantButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("RegistrationPage");
                frame.setContentPane(new RegistrationPage().MainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                SwingUtilities.getWindowAncestor(MainPanel).dispose();
            }

        });
        slotFinderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("SlotFinderGUI");
                frame.setContentPane(new SlotFinderGUI().MainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                SwingUtilities.getWindowAncestor(MainPanel).dispose();
            }
        });
        eventSchedulerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("EventSchedulerGUI");
                frame.setContentPane(new EventSchedulerGUI().MainPanel);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                dispose();
                SwingUtilities.getWindowAncestor(MainPanel).dispose();
            }
        });
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

    }

}
