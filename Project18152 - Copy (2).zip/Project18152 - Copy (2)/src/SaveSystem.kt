import java.sql.*
import java.time.LocalDate
import java.time.LocalTime
import javax.swing.JFrame
import javax.swing.JOptionPane
import javax.swing.SwingUtilities


object SaveSystem {


    //url specifies the database file location
    // Create a connection to the database
    //connection object is an active link between kotlin app and a database

    public
    val connection: Connection = DriverManager.getConnection("jdbc:sqlite:test.db")

    public var currentTable: MutableList<TempEvent> = mutableListOf()

    fun createTable() {

        //statement object lets you send SQL commands to database and retrieve
        val statement: Statement = connection.createStatement()

        //statement.execute("DROP TABLE IF EXISTS Events")
        //statement.execute("DROP TABLE IF EXISTS Venues")
        // Create a new table
        statement.execute(
            """
           CREATE TABLE IF NOT EXISTS Events (
id TEXT PRIMARY KEY,
eventName TEXT,
date TEXT,
startTime TEXT,
endTime TEXT,
venueID TEXT,
venueName TEXT,
FOREIGN KEY (venueID) REFERENCES Venues(vID)
)
"""
        )
        //if an event is deleted, all associated venues via vID are also deleted

        statement.execute(
            """
CREATE TABLE IF NOT EXISTS Venues (
vID TEXT PRIMARY KEY,
vName TEXT,
location TEXT,
capacity INTEGER,
currentCapacity INTEGER
)
"""
        )



       createDataList()
    }

    fun createDataList()
    {
        val statement: Statement = connection.createStatement()

        val query = statement.executeQuery(
            "SELECT id, eventName, date, startTime, endTime, venueID, venueName, location, capacity, currentCapacity " +
                    "FROM Events " +
                    "INNER JOIN Venues ON Events.venueID = Venues.vID ORDER BY Events.date, Events.startTime"
        )

        while (query.next()) {
            currentTable.add(
                TempEvent(
                    venueID = query.getString("venueID"),
                    eventName = query.getString("eventName"),
                    venue = query.getString("venueName"),
                    location = query.getString("location"),
                    date = LocalDate.parse(query.getString("date")),
                    startTime = LocalTime.parse(query.getString("startTime")),
                    endTime = LocalTime.parse(query.getString("endTime")),
                    capacity = query.getInt("capacity"),
                    currentCapacity = query.getInt("currentCapacity")
                )
            )
        }




    }

    fun checkIfEmpty() : Boolean
    {
        var empty = false;
        val statement: Statement = connection.createStatement()

        val count : ResultSet = statement.executeQuery("SELECT COUNT(*) AS Count FROM Events")
        if(count.getInt("Count") == 0)
            empty = true

        return empty
    }

    fun insertData(eventString: String, venueString: String) {

        eventString.split("|||")
        val eventData = eventString.split("|||")
        val id = eventData.getOrNull(0) ?: ""
        val name = eventData.getOrNull(1) ?: ""
        val date = eventData.getOrNull(2) ?: ""
        val startTime = eventData.getOrNull(3) ?: ""
        val endTime = eventData.getOrNull(4) ?: ""

        venueString.split("|||")
        val venueData = venueString.split("|||")
        val venueID = venueData.getOrNull(0) ?: ""
        val venueName = venueData.getOrNull(1) ?: ""
        val location = venueData.getOrNull(2) ?: ""
        val capacity = venueData.getOrNull(3) ?: ""

        // Insert data into the table
        val statement: Statement = connection.createStatement()

        statement.execute(
            """
INSERT OR REPLACE INTO Events (id, eventName, date, startTime, endTime, venueID, venueName)
VALUES ('$id', '$name', '$date', '$startTime', '$endTime', '$venueID', '$venueName')
""")

        statement.execute(
            """
INSERT OR REPLACE INTO Venues (vID, vName, location, capacity, currentCapacity)
VALUES ('$venueID', '$venueName', '$location', '$capacity', 0)
"""
        )

        currentTable.add(
            TempEvent(
                venueID = venueID,
                eventName = name,
                venue = venueName,
                location = location,
                date = LocalDate.parse(date),
                startTime = LocalTime.parse(startTime),
                endTime = LocalTime.parse(endTime),
                capacity = capacity.toInt(),
                currentCapacity = 0
            )
        )

        currentTable.clear();
        createDataList();
    }

    fun showTable()
    {
        val statement: Statement = connection.createStatement()
        val resultSet = statement.executeQuery("""
    SELECT 
        Events.id, Events.eventName, Events.date, Events.startTime, Events.endTime, Events.venueID, Events.venueName,
        Venues.vID, Venues.vName, Venues.location, Venues.capacity, Venues.currentCapacity
    FROM Events
    INNER JOIN Venues ON Events.venueID = Venues.vID  ORDER BY Events.date, Events.startTime 
""")

        while (resultSet.next()) {
            // Print Event details
            println("===========")
            println(
                "Event: [Venue ID=${resultSet.getString("venueID")}, Name=${resultSet.getString("eventName")}, " +
                        "Date=${resultSet.getString("date")}, Start=${resultSet.getString("startTime")}," +
                        "End=${resultSet.getString("endTime")}, venueName=${resultSet.getString("venueName")}"
            )
            // Print Venue details
            println(
                "Venue: [Name=${resultSet.getString("vName")}, " +
                        "Location=${resultSet.getString("location")}, Capacity=${resultSet.getString("capacity")}, " +
                        "CurrentCapacity=${resultSet.getString("currentCapacity")}]"
            )
            println("------")
        }

    }
    fun addToVenue(venueID: String) : Boolean {



        var venueFull = true

        //prepared statement to prevent SQL injection

        val checkCapacity = "SELECT capacity, currentCapacity FROM Venues WHERE vID = ?"
        val stmt : PreparedStatement = connection.prepareStatement(checkCapacity)
        stmt.setString(1, venueID)
        val result : ResultSet = stmt.executeQuery()



        //add existing

        if (result.next()) {
            val capacity = result.getInt("capacity")
            val currentCapacity = result.getInt("currentCapacity")
            if (currentCapacity < capacity) {
                val updateCapacity = "UPDATE Venues SET currentCapacity = currentCapacity + 1 WHERE vID = ?"
                val stmt: PreparedStatement = connection.prepareStatement(updateCapacity)
                stmt.setString(1, venueID)
                stmt.executeUpdate()

                venueFull = false
            } else
                venueFull = true

            showTable()
        }
        currentTable.clear();
        createDataList();
            return venueFull


    }
}