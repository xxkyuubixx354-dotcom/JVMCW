data class Event(
    val id: String,
    val name: String,
    val date: String,
    val startTime: String,
    val endTime: String
)
{
    constructor(id: String, name: String) : this(
        id,
        name,
        date = "",
        startTime = "",
        endTime = ""
    )
}
